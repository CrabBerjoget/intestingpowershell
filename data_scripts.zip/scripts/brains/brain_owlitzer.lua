local ChaseAndAttack = require("behaviors/chaseandattack")
local KnockdownRecovery = require("behaviors/knockdownrecovery")
local Wander = require("behaviors/wander")
local TargetLastAttacker = require ("behaviors.targetlastattacker")

local BrainOwlitzer = Class(Brain, function(self, inst)
	Brain._ctor(self, inst, PriorityNode({
		KnockdownRecovery(inst),
		TargetLastAttacker(inst),
		ChaseAndAttack(inst),
		Wander(inst, Vector3(0, 0, 0), 12),
	}, .1))
end)

return BrainOwlitzer
